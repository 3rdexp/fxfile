#include "StdAfx.h"
#include "GflAX_i.c"


class CGflAXModule : public CAtlDllModuleT< CGflAXModule >
{
public :
	DECLARE_LIBID(LIBID_GflAx)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_GFLAX, "{50844918-212F-4F93-92C4-18CF4B96DB74}")
};


CGflAXModule *_Module = NULL;


////////////////////////////////////////////////////////////////////////////
// Javne funkcije
////////////////////////////////////////////////////////////////////////////

extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
    UNREFERENCED_PARAMETER(hInstance);
    
    if (dwReason == DLL_PROCESS_ATTACH) {
        // Prepare the module instance on the heap.
        _Module = new CGflAXModule();
        
        return _Module->DllMain(dwReason, lpReserved);
    } else if (dwReason == DLL_PROCESS_DETACH) {
        BOOL bRes = _Module->DllMain(dwReason, lpReserved);
        
        // Free the module instance.
        if (_Module) {
            delete _Module;
            _Module = NULL;
        };

        // Release all class factories.
        ATL::_AtlComModule.Term();
#ifdef _DEBUG
        _CrtDumpMemoryLeaks();
#endif
        return bRes;
    } else {
        return _Module->DllMain(dwReason, lpReserved);
    }
}


STDAPI DllCanUnloadNow()
{
    return _Module->DllCanUnloadNow();
}


STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module->DllGetClassObject(rclsid, riid, ppv);
}


STDAPI DllRegisterServer()
{
    return _Module->DllRegisterServer();
}


STDAPI DllUnregisterServer()
{
    return _Module->DllUnregisterServer();
}


STDAPI DllInstall(BOOL bInstall, LPCWSTR pszCmdLine)
{
    HRESULT hr;
    static const wchar_t szUserSwitch[] = L"user";

    if (pszCmdLine != NULL) {
        if (_wcsnicmp(pszCmdLine, szUserSwitch, _countof(szUserSwitch)) == 0)
            AtlSetPerUserRegistration(true);
    }

    if (bInstall) {    
        hr = DllRegisterServer();
        if (FAILED(hr))
            DllUnregisterServer();
    } else
        hr = DllUnregisterServer();

    return hr;
}
